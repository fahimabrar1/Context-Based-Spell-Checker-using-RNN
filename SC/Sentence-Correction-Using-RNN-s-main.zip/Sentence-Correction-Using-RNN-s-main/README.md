 
                                           Sentence Correction using RNN’s
Instigation:
The information exchange between people rapidly increasing through different social media channels (Facebook, Twitter etc.). People started texting short form of messages and using different terminologies to convey the information. This short form of messages(Fast text) creating big impact and drastically reducing the performance of machine learning models which runs on this data. And it slowly led to make wrong predictions and wrong interpretation from ML models. Gene Lewis published a research paper from Stanford University and proposed an approach to overcome this problem in the field of AI. 

